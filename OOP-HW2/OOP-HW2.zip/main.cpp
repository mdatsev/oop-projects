#include <iostream>
#include <memory>

#include "App.hpp"

int main() {
    App().run();
    return 0;
}